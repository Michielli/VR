package model.domain;

public class Matricula {
    
    Integer codigo_aluno;
    Integer codigo_curso;

    public Integer getCodigo_aluno() {
        return codigo_aluno;
    }

    public void setCodigo_aluno(Integer codigo_aluno) {
        this.codigo_aluno = codigo_aluno;
    }

    public Integer getCodigo_curso() {
        return codigo_curso;
    }

    public void setCodigo_curso(Integer codigo_curso) {
        this.codigo_curso = codigo_curso;
    }
    
    public Matricula(){
        
    }

    public String getAluno() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public String getDescricao() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

      
    
    
}
