package model.dao;

import factory.ConnectionFactory;
import model.domain.Curso;
import java.sql.*;
import javax.swing.JOptionPane;

public class CursoDAO {

    private final Connection connection;

    String nome;
    String ementa;

    public CursoDAO() {
        this.connection = new ConnectionFactory().getConnection();
    }

    public void adiciona(Curso curso) {
        String sql = "INSERT INTO curso(descricao, ementa) VALUES(?,?)";
        try {
            PreparedStatement stmt = connection.prepareStatement(sql);
            stmt.setString(1, curso.getDescricao());
            stmt.setString(2, curso.getEmenta());

            JOptionPane.showMessageDialog(null, "Curso adicionado com sucesso");

            stmt.execute();
            stmt.close();
        } catch (SQLException u) {
            JOptionPane.showMessageDialog(null, "Erro na comunicação com o Banco de dados" + u);
            throw new RuntimeException(u);
        }
    }

    
    public Iterable<Curso> read() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
