package model.dao;

import factory.ConnectionFactory;
import model.domain.Aluno;
import java.sql.*;


public class AlunoDAO {
    
    private Connection connection;
    
    String nome;

    public AlunoDAO(){ 
        this.connection = new ConnectionFactory().getConnection();
    } 
    public void adiciona(Aluno aluno){ 
        String sql = "INSERT INTO aluno(nome) VALUES(?)";
        try { 
            PreparedStatement stmt = connection.prepareStatement(sql);
            stmt.setString(1, aluno.getNome());
            
            stmt.execute();
            stmt.close();
        } 
        catch (SQLException u) { 
            throw new RuntimeException(u);
        } 
        
    } 
    
}
