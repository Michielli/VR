package model.dao;

import factory.ConnectionFactory;
import model.domain.Matricula;
import java.sql.*;
import javax.swing.JOptionPane;
import view.MatriculaView;

public class MatriculaDAO {
    private final Connection connection;

    Integer codigo_aluno;
    Integer codigo_curso;

    public MatriculaDAO() {
        this.connection = new ConnectionFactory().getConnection();
    }

    public void adiciona(Matricula matricula) {
        String sql = "INSERT INTO curso_aluno(codigo_aluno, codigo_curso) VALUES(?,?)";
        try {
            PreparedStatement stmt = connection.prepareStatement(sql);
            stmt.setString(1, matricula.getAluno());
            stmt.setString(2, matricula.getDescricao());

            JOptionPane.showMessageDialog(null, "Curso adicionado com sucesso");

            stmt.execute();
            stmt.close();
        } catch (SQLException u) {
            JOptionPane.showMessageDialog(null, "Erro na comunicação com o Banco de dados" + u);
            throw new RuntimeException(u);
        }
    }

    
    public Iterable<Matricula> read() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public void adiciona(MatriculaView matricula) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
