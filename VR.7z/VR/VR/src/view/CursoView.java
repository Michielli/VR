package view;

import model.dao.CursoDAO;
import model.domain.Curso;


public class CursoView extends javax.swing.JInternalFrame {

    public CursoView() {
        initComponents();
        
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Detalhes = new javax.swing.JPanel();
        txtDescricao = new javax.swing.JLabel();
        txtEmenta = new javax.swing.JLabel();
        LDescricao = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        AreatxtEmenta = new javax.swing.JTextArea();
        Botoes = new javax.swing.JPanel();
        btnSalvar = new javax.swing.JButton();

        setClosable(true);

        txtDescricao.setText("Descrição");

        txtEmenta.setText("Ementa");

        LDescricao.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LDescricaoActionPerformed(evt);
            }
        });

        AreatxtEmenta.setColumns(20);
        AreatxtEmenta.setRows(5);
        jScrollPane1.setViewportView(AreatxtEmenta);

        javax.swing.GroupLayout DetalhesLayout = new javax.swing.GroupLayout(Detalhes);
        Detalhes.setLayout(DetalhesLayout);
        DetalhesLayout.setHorizontalGroup(
            DetalhesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(DetalhesLayout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(DetalhesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1)
                    .addGroup(DetalhesLayout.createSequentialGroup()
                        .addGroup(DetalhesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtEmenta)
                            .addComponent(txtDescricao))
                        .addGap(0, 327, Short.MAX_VALUE))
                    .addComponent(LDescricao))
                .addContainerGap())
        );
        DetalhesLayout.setVerticalGroup(
            DetalhesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(DetalhesLayout.createSequentialGroup()
                .addGap(40, 40, 40)
                .addComponent(txtDescricao)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(LDescricao, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(txtEmenta)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(19, Short.MAX_VALUE))
        );

        btnSalvar.setText("Salvar");
        btnSalvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalvarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout BotoesLayout = new javax.swing.GroupLayout(Botoes);
        Botoes.setLayout(BotoesLayout);
        BotoesLayout.setHorizontalGroup(
            BotoesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(BotoesLayout.createSequentialGroup()
                .addContainerGap(175, Short.MAX_VALUE)
                .addComponent(btnSalvar)
                .addGap(170, 170, 170))
        );
        BotoesLayout.setVerticalGroup(
            BotoesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(BotoesLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnSalvar)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(Detalhes, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(Botoes, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addContainerGap(23, Short.MAX_VALUE))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(Detalhes, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Botoes, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void LDescricaoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LDescricaoActionPerformed

    }//GEN-LAST:event_LDescricaoActionPerformed

    private void btnSalvarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalvarActionPerformed
        // instanciando a classe Usuario do pacote modelo e criando seu objeto usuarios
        Curso curso = new Curso();
        curso.setDescricao(LDescricao.getText());
        curso.setEmenta(AreatxtEmenta.getText());

        // fazendo a validação dos dados
        if ((LDescricao.getText().isEmpty()) || (AreatxtEmenta.getText().isEmpty())) {
           //JOptionPane.showMessageDialog(null, "Os campos não podem retornar vazios");
        }
        else {

            // instanciando a classe UsuarioDAO do pacote dao e criando seu objeto dao
            CursoDAO dao = new CursoDAO();        
            dao.adiciona(curso);
            //JOptionPane.showMessageDialog(null, "Usuário "+jTextField1.getText()+" inserido com sucesso! ");
        }

        // apaga os dados preenchidos nos campos de texto
        LDescricao.setText("");
        AreatxtEmenta.setText("");
        
        
        
    }//GEN-LAST:event_btnSalvarActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextArea AreatxtEmenta;
    private javax.swing.JPanel Botoes;
    private javax.swing.JPanel Detalhes;
    private javax.swing.JTextField LDescricao;
    private javax.swing.JButton btnSalvar;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel txtDescricao;
    private javax.swing.JLabel txtEmenta;
    // End of variables declaration//GEN-END:variables
}
