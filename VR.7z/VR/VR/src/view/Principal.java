package view;

public class Principal extends javax.swing.JFrame {

    public Principal() {
        initComponents();
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        desktopPane = new javax.swing.JDesktopPane();
        menuBar = new javax.swing.JMenuBar();
        MNCadastro = new javax.swing.JMenu();
        MNCurso = new javax.swing.JMenuItem();
        MNAluno = new javax.swing.JMenuItem();
        MNMatricula = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        MNCadastro.setMnemonic('f');
        MNCadastro.setText("Cadastro");

        MNCurso.setMnemonic('o');
        MNCurso.setText("Curso");
        MNCurso.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MNCursoActionPerformed(evt);
            }
        });
        MNCadastro.add(MNCurso);

        MNAluno.setMnemonic('s');
        MNAluno.setText("Aluno");
        MNAluno.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MNAlunoActionPerformed(evt);
            }
        });
        MNCadastro.add(MNAluno);

        MNMatricula.setMnemonic('x');
        MNMatricula.setText("Matrícula");
        MNMatricula.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MNMatriculaActionPerformed(evt);
            }
        });
        MNCadastro.add(MNMatricula);

        menuBar.add(MNCadastro);

        setJMenuBar(menuBar);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(desktopPane, javax.swing.GroupLayout.DEFAULT_SIZE, 452, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(desktopPane, javax.swing.GroupLayout.PREFERRED_SIZE, 613, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void MNMatriculaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MNMatriculaActionPerformed
        MatriculaView matricula = new MatriculaView();
        this.desktopPane.add(matricula);
        matricula.setVisible(true);
    }//GEN-LAST:event_MNMatriculaActionPerformed

    private void MNCursoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MNCursoActionPerformed
        // TODO add your handling code here:
        
        CursoView curso = new CursoView();
        this.desktopPane.add(curso);
        curso.setVisible(true);
    }//GEN-LAST:event_MNCursoActionPerformed

    private void MNAlunoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MNAlunoActionPerformed
        // TODO add your handling code here:
        
        AlunoView aluno = new AlunoView();
        this.desktopPane.add(aluno);
        aluno.setVisible(true);
    }//GEN-LAST:event_MNAlunoActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Principal().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuItem MNAluno;
    private javax.swing.JMenu MNCadastro;
    private javax.swing.JMenuItem MNCurso;
    private javax.swing.JMenuItem MNMatricula;
    private javax.swing.JDesktopPane desktopPane;
    private javax.swing.JMenuBar menuBar;
    // End of variables declaration//GEN-END:variables

}
